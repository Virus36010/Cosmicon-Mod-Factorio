data:extend ({
  {
    type = "item",
    name = "speed-furnace1",
    icon = "__Cosmicon__/mod/graphics/icons/speed-furnace1.png",
    icon_size=32,
    scale = 0.5,
    subgroup = "CosmiconItems-furnaces",
    stack_size = 50,
    place_result = "speed-furnace1"
  },

})