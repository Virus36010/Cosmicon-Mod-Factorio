data:extend ({
  {
    type = "recipe",
    name = "speed-furnace1",
    energy_required = 15.0,
    ingredients = {
      {"steel-plate",60},
      {"electric-engine-unit",10},
      {"processing-unit",15}
    },
    enabled = false,
    result = "speed-furnace1",
    icon = "__Cosmicon__/mod/graphics/icons/speed-furnace1.png",
    icon_size = 32,
    scale = 0.5,
    subgroup = "CosmiconItems-furnaces",
    order = "a",
  },

})