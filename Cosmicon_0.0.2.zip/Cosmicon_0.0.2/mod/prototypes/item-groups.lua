data:extend({
---------------------------------------------------------COSMICON-GROUP
  {
    type="item-group",
    name="CosmiconItems",
    icon="__Cosmicon__/mod/graphics/icons/Cosmicon.png",
    icon_size=128,
    icon_mipmaps = 2,
    scale=0.5,
    order="k"
  },

  {
    type = "item-subgroup",
    name = "CosmiconItems-furnaces",
    group = "CosmiconItems",
    order = "a",
  },

  {
    type = "item-subgroup",
    name = "CosmiconItems-drills",
    group = "CosmiconItems",
    order = "b",
  },

})