data:extend({
    ---------------------------------------Flat-solar-panel-1
    {------------Item

    },
    {------------Recipe

    },
    {------------Technology
        data.raw["technology"]["solar-energy"].effects={
            {
                type = "unlock-recipe",
                recipe = "flat-solar-panel-1"
            },
            {
                type = "unlock-recipe",
                recipe = "solar-panel"
            }
        }
    },
    {------------Entity
        type = "tile",
        name = "flat-solar-panel-1",
        order = "a[artificial]-b[tier-2]-a[concrete]",
        needs_correction = false,
        minable = {mining_time = 0.1, result = "flat-solar-panel-1"},
        mined_sound = sounds.deconstruct_bricks(0.8),
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.0,
        layer = 61,
        transition_overlay_layer_offset = 2,
        decorative_removal_probability = 0.25,
    },

    ---------------------------------------Solar-panel-2
    {------------Item
        type="item",
        name = "solar-panel-2",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-2.png",
        icon_size=64,
        scale = 0.5,
        subgroup = "CosmiconItems-solar-panels",
        stack_size = 50,
        place_result = "solar-panel-2"
    },
    {------------Recipe
        type="recipe",
        name = "solar-panel-2",
        energy_required = 20.0,
        ingredients = {
            {"steel-plate",60},
            {"electric-engine-unit",10},
            {"processing-unit",15},
            {"solar-panel",3}
        },
        enabled = false,
        result = "solar-panel-2",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-2.png",
        icon_size = 64,
        scale = 0.5,
        subgroup = "CosmiconItems-solar-panels",
        order = "a",
    },
    {------------Technology
        type="technology",
        name = "solar-energy-2",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/technology/solar-energy-2.png", 
        icon_size = 32,
        effects = {
            {
                type = "unlock-recipe",
                recipe = "solar-panel-2"
            }
        },
        prerequisites = {"advanced-electronics-2","electric-engine","utility-science-pack"},
        unit = {
            count = 50,
            ingredients = {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
                {"chemical-science-pack", 1},
                {"production-science-pack", 1}
            },
            time = 15
        } 
    },
    {------------Entity
        type="solar-panel",
        name="solar-panel-2",
        production = "180kW",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-2.png",
        icon_size = 32, icon_mipmaps = 4,
        flags = {"placeable-neutral", "placeable-player", "player-creation"},
        minable = {mining_time = 0.2, result = "solar-panel-2"},
        max_health = 400,
        fast_replaceable_group = "solar-panel",
        collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
        selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
        energy_source ={
            type = "electric",
            usage_priority = "solar"
        },

        picture={
            filename = "__Cosmicon-Solar-Panels__/mod/graphics/entities/solar-panel-2-entity.png",
            priority = "high",
            width = 116,
            height = 112,
            frame_count = 1,
            shift = {0, 0}
        }
    },
    ---------------------------------------Flat-solar-panel-2


    ---------------------------------------Solar-panel-3
    {------------Item
        type="item",
        name = "solar-panel-3",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-3.png",
        icon_size=64,
        scale = 0.5,
        subgroup = "CosmiconItems-solar-panels",
        stack_size = 50,
        place_result = "solar-panel-3"
    },
    {------------Recipe
        type="recipe",
        name = "solar-panel-3",
        energy_required = 20.0,
        ingredients = {
            {"steel-plate",60},
            {"electric-engine-unit",10},
            {"processing-unit",15},
            {"solar-panel-2",3}
        },
        enabled = false,
        result = "solar-panel-3",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-3.png",
        icon_size = 64,
        scale = 0.5,
        subgroup = "CosmiconItems-solar-panels",
        order = "b",
    },
    {------------Technology
        type="technology",
        name = "solar-energy-3",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/technology/solar-energy-3.png", 
        icon_size = 32,
        effects = {
            {
                type = "unlock-recipe",
                recipe = "solar-panel-3"
            }
        },
        prerequisites = {"solar-energy-2"},
        unit = {
            count = 100,
            ingredients = {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
                {"chemical-science-pack", 1},
                {"production-science-pack", 1}
            },
            time = 15
        } 
    },
    {------------Entity
        type="solar-panel",
        name="solar-panel-3",
        production = "540kW",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-3.png",
        icon_size = 32, icon_mipmaps = 4,
        flags = {"placeable-neutral", "placeable-player", "player-creation"},
        minable = {mining_time = 0.2, result = "solar-panel-3"},
        max_health = 400,
        fast_replaceable_group = "solar-panel",
        collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
        selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
        energy_source ={
            type = "electric",
            usage_priority = "solar"
        },

        picture={
            filename = "__Cosmicon-Solar-Panels__/mod/graphics/entities/solar-panel-3-entity.png",
            priority = "high",
            width = 116,
            height = 112,
            frame_count = 1,
            shift = {0, 0},
        }
    },

    ---------------------------------------Solar-panel-4
    {------------Item
        type="item",
        name = "solar-panel-4",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-4.png",
        icon_size=64,
        scale = 0.5,
        subgroup = "CosmiconItems-solar-panels",
        stack_size = 50,
        place_result = "solar-panel-4"
    },
    {------------Recipe
        type="recipe",
        name = "solar-panel-4",
        energy_required = 20.0,
        ingredients = {
            {"steel-plate",60},
            {"electric-engine-unit",10},
            {"processing-unit",15},
            {"solar-panel-3",3}
        },
        enabled = false,
        result = "solar-panel-4",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-4.png",
        icon_size = 64,
        scale = 0.5,
        subgroup = "CosmiconItems-solar-panels",
        order = "c",
    },
    {------------Technology
        type="technology",
        name = "solar-energy-4",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/technology/solar-energy-4.png", 
        icon_size = 32,
        effects = {
            {
                type = "unlock-recipe",
                recipe = "solar-panel-4"
            }
        },
        prerequisites = {"solar-energy-3"},
        unit = {
            count = 150,
            ingredients = {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
                {"chemical-science-pack", 1},
                {"production-science-pack", 1}
            },
            time = 25
        } 
    },
    {------------Entity
        type="solar-panel",
        name="solar-panel-4",
        production = "1620kW",
        icon = "__Cosmicon-Solar-Panels__/mod/graphics/icons/solar-panel-4.png",
        icon_size = 32, icon_mipmaps = 4,
        flags = {"placeable-neutral", "placeable-player", "player-creation"},
        minable = {mining_time = 0.2, result = "solar-panel-4"},
        max_health = 400,
        fast_replaceable_group = "solar-panel",
        collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
        selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
        energy_source ={
            type = "electric",
            usage_priority = "solar"
        },

        picture={
            filename = "__Cosmicon-Solar-Panels__/mod/graphics/entities/solar-panel-4-entity.png",
            priority = "high",
            width = 116,
            height = 112,
            frame_count = 1,
            shift = {0, 0}
        }
    },

    ---------------------------------------Space-Solar-Array (future)
    --places in space
    --produces about 10'000kW or more
    --costs many resources
    --unlocks after spaceships

    --P.S. maybe i'll add dyson sphere
})