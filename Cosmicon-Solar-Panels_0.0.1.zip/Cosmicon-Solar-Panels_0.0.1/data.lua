require("mod.prototypes.solar-panels")
require("mod.prototypes.accumulators")